#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
付费技能服务端源码 · 买家侧交付脚本

三种用法：

  1) 取账单（首次，得到金额与订单号）
     python scripts/fetch-source.py

  2) 手工付款后组装协议头（把 payment_proof 与 trade_no 变成 Payment-Proof）
     python scripts/fetch-source.py --make-proof \
         --payment-proof "<payment_proof>" --trade-no "<trade_no>"

  3) 领取交付物（带上凭据重发同一请求）
     python scripts/fetch-source.py --proof "<Payment-Proof>"

仅使用 Python 标准库，无需安装任何依赖。

退出码：0 成功 · 1 请求失败 · 3 需要支付 · 4 资源未上架
"""

import argparse
import base64
import hashlib
import json
import os
import sys
import urllib.error
import urllib.request

# 必须是 HTTPS —— 支付宝 CLI 硬性拒绝 HTTP 资源地址（Error: paid resource URL must use HTTPS）。
# 注意：下方为隧道临时地址，服务器重启后会变。卖家换固定域名后需同步更新此处；
# 买家可用环境变量 PAY_SERVICE_RESOURCE_URL 临时覆盖，不必改代码。
DEFAULT_RESOURCE_URL = "https://respect-champions-anime-mattress.trycloudflare.com/v1/skills/ym-pay-service-source/result"

# 资源未上架时服务端返回 404（不是 402）——这是刻意设计，见 SKILL.md 常见坑第 4 条。
EXIT_OK = 0
EXIT_FAIL = 1
EXIT_NEED_PAY = 3
EXIT_NOT_LISTED = 4


def b64url_decode(text):
    """Base64URL 解码。可能省略 '=' 补位，必须先补齐。"""
    normalized = text.replace("-", "+").replace("_", "/")
    normalized += "=" * ((4 - len(normalized) % 4) % 4)
    return base64.b64decode(normalized).decode("utf-8")


def b64url_encode(text):
    """Base64URL 编码，去掉 '=' 补位以贴近协议实现。"""
    return base64.urlsafe_b64encode(text.encode("utf-8")).decode("ascii").rstrip("=")


def build_proof_header(payment_proof, trade_no, client_session=None):
    """按协议格式组装 Payment-Proof 头。"""
    payload = {
        "protocol": {"payment_proof": payment_proof, "trade_no": trade_no},
    }
    if client_session:
        payload["method"] = {"client_session": client_session}
    return b64url_encode(json.dumps(payload, ensure_ascii=False, separators=(",", ":")))


def pick_header(headers, name):
    """响应头大小写不敏感查找。"""
    for key, value in headers.items():
        if key.lower() == name.lower():
            return value
    return None


def http_get(url, proof=None, timeout=120):
    """发一次 GET；HTTP 错误码也当正常返回，交由上层按状态码分流。"""
    request = urllib.request.Request(url, method="GET")
    request.add_header("Accept", "application/json")
    if proof:
        request.add_header("Payment-Proof", proof)

    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.status, dict(response.headers), response.read().decode("utf-8")
    except urllib.error.HTTPError as error:
        return error.code, dict(error.headers), error.read().decode("utf-8", "replace")


def print_bill(bill):
    protocol = bill.get("protocol", {})
    method = bill.get("method", {})

    print("需要支付")
    print("─" * 52)
    print("  商品    %s" % method.get("goods_name", "-"))
    print("  收款方  %s" % method.get("seller_name", "-"))
    print("  金额    %s %s" % (protocol.get("amount", "-"), protocol.get("currency", "")))
    print("  订单号  %s" % protocol.get("out_trade_no", "-"))
    print("  截止    %s" % protocol.get("pay_before", "-"))
    print("  资源    %s" % protocol.get("resource_id", "-"))
    print("─" * 52)
    print("")
    print("完成支付后，任选一种方式取回交付物：")
    print("")
    print("  A. 若环境具备 AI 付能力：直接用取得的 Payment-Proof 领取")
    print("     python scripts/fetch-source.py --proof \"<Payment-Proof>\"")
    print("")
    print("  B. 手工付款：拿到 payment_proof 与 trade_no 后先组装协议头")
    print("     python scripts/fetch-source.py --make-proof \\")
    print("         --payment-proof \"<payment_proof>\" --trade-no \"<trade_no>\"")
    print("     再把打印出来的头部值作为 --proof 传回去。")
    print("")
    print("注意：重试必须原样重发同一请求；超时也用同一凭据重试，不要重新付款。")


def save_delivery(outer, out_dir, expected_name):
    """解析两层 JSON，把交付物落盘并校验 SHA-256。"""
    try:
        inner = json.loads(outer.get("content", ""))
    except (TypeError, ValueError):
        print("交付失败：响应中的 content 不是合法 JSON。", file=sys.stderr)
        print("原始 content：%s" % outer.get("content", "")[:500], file=sys.stderr)
        return EXIT_FAIL

    delivery = inner.get("delivery")
    if not delivery:
        print("交付失败：响应里没有 delivery 字段。", file=sys.stderr)
        print(json.dumps(inner, ensure_ascii=False, indent=2), file=sys.stderr)
        return EXIT_FAIL

    if delivery.get("type") == "text":
        name = os.path.basename(delivery.get("file_name") or expected_name + ".txt")
        target = os.path.join(out_dir, name)
        with open(target, "w", encoding="utf-8") as handle:
            handle.write(delivery.get("content", ""))
        print("交付成功（文本）")
        print("  文件      %s" % os.path.abspath(target))
        return EXIT_OK

    if delivery.get("type") != "file_base64":
        print("交付失败：未知的交付类型 %s。" % delivery.get("type"), file=sys.stderr)
        return EXIT_FAIL

    raw = base64.b64decode(delivery.get("content_base64", ""))
    actual = hashlib.sha256(raw).hexdigest()
    declared = (delivery.get("sha256") or "").lower()

    name = os.path.basename(delivery.get("file_name") or expected_name)
    target = os.path.join(out_dir, name)

    with open(target, "wb") as handle:
        handle.write(raw)

    print("交付成功")
    print("  文件      %s" % os.path.abspath(target))
    print("  大小      %d 字节（声明 %s）" % (len(raw), delivery.get("size_bytes", "-")))
    print("  SHA-256   %s" % actual)
    if outer.get("trade_no"):
        print("  交易号    %s" % outer["trade_no"])
    if outer.get("already_fulfilled"):
        print("  说明      复用既有产出（同一凭据重复领取，未重复扣费）")

    if declared and actual != declared:
        print("", file=sys.stderr)
        print("交付文件校验失败：实际摘要与声明不一致，请用同一凭据重试。", file=sys.stderr)
        return EXIT_FAIL

    print("  校验通过")
    print("")
    print("解压后即为服务端源码目录，编译、配置与部署步骤见包内 docs/接入教程.md。")
    return EXIT_OK


def main():
    parser = argparse.ArgumentParser(
        description="付费技能服务端源码 · 买家侧交付脚本",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--proof", help="Payment-Proof 头内容；提供即进入领取流程")
    parser.add_argument("--make-proof", action="store_true", help="只组装 Payment-Proof 并打印")
    parser.add_argument("--payment-proof", help="手工付款得到的 payment_proof")
    parser.add_argument("--trade-no", help="手工付款得到的 trade_no")
    parser.add_argument("--client-session", help="可选，客户端会话标识")
    parser.add_argument("--out", default=".", help="交付物输出目录，默认当前目录")
    parser.add_argument(
        "--url",
        default=os.environ.get("PAY_SERVICE_RESOURCE_URL", DEFAULT_RESOURCE_URL),
        help="资源地址，默认取环境变量 PAY_SERVICE_RESOURCE_URL 或内置地址",
    )
    parser.add_argument("--timeout", type=int, default=120, help="请求超时秒数，默认 120")
    args = parser.parse_args()

    if args.make_proof:
        if not args.payment_proof or not args.trade_no:
            print("--make-proof 需要同时提供 --payment-proof 与 --trade-no。", file=sys.stderr)
            return EXIT_FAIL
        header = build_proof_header(args.payment_proof, args.trade_no, args.client_session)
        print(header)
        return EXIT_OK

    expected_name = "paid-skill-service-source-v1.0.0.zip"

    try:
        status, headers, body = http_get(args.url, args.proof, args.timeout)
    except urllib.error.URLError as error:
        print("请求失败：%s" % error.reason, file=sys.stderr)
        print("请确认网络可达，或检查 --url / PAY_SERVICE_RESOURCE_URL。", file=sys.stderr)
        return EXIT_FAIL
    except TimeoutError:
        print("请求超时。服务端履约与连接是脱钩的 ——", file=sys.stderr)
        print("请用同一 Payment-Proof 重试，不要重新发起支付。", file=sys.stderr)
        return EXIT_FAIL

    if status == 402:
        raw = pick_header(headers, "Payment-Needed")
        if not raw:
            print("收到 402 但没有 Payment-Needed 头，无法定位问题。", file=sys.stderr)
            return EXIT_FAIL
        try:
            print_bill(json.loads(b64url_decode(raw)))
        except ValueError as error:
            print("账单解码失败：%s" % error, file=sys.stderr)
            return EXIT_FAIL

        if args.proof:
            print("")
            print("凭据未被接受（金额、资源或订单校验未通过），请核对后重新取账单。")
        return EXIT_NEED_PAY

    if status == 404:
        print("资源未上架或编码写错（HTTP 404）。请检查地址：%s" % args.url, file=sys.stderr)
        return EXIT_NOT_LISTED

    if status != 200:
        print("请求失败：HTTP %d" % status, file=sys.stderr)
        print(body[:800], file=sys.stderr)
        if status >= 500:
            print("", file=sys.stderr)
            print("服务端错误：请保留凭据，稍后用同一凭据重试，不要重新发起支付。", file=sys.stderr)
        return EXIT_FAIL

    try:
        outer = json.loads(body)
    except ValueError:
        print("响应不是合法 JSON：%s" % body[:500], file=sys.stderr)
        return EXIT_FAIL

    if not outer.get("fulfillment_confirmed", True):
        print("提示：服务端尚未确认履约，若拿不到交付物请用同一凭据重试。", file=sys.stderr)

    os.makedirs(args.out, exist_ok=True)
    return save_delivery(outer, args.out, expected_name)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("已中断。已付款的订单可用同一凭据重新领取。", file=sys.stderr)
        sys.exit(EXIT_FAIL)
