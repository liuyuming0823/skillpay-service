#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
付费技能服务端源码 · 一键购买

把「取账单 → 付款 → 轮询 → 落盘 → 校验 → 回执」串成一条命令，
不用手敲四步、也不用记住账单必须原样保存这类细节。

    python scripts/buy.py                       # 完整流程
    python scripts/buy.py --yes                 # 跳过付款前的二次确认
    python scripts/buy.py --trade-no <交易号>   # 已付款，只取货（超时/断连后用这个）
    python scripts/buy.py --out <目录>          # 指定交付物落盘位置

仅使用 Python 标准库。退出码：0 成功 · 1 失败 · 2 环境未就绪 · 3 需人工付款
"""

import argparse
import base64
import hashlib
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from preflight import (  # noqa: E402
    MISSING, OK, DEFAULT_RESOURCE_URL, check_bot, check_node, check_python, find_alipay_bot,
)

EXIT_OK, EXIT_FAIL, EXIT_ENV, EXIT_NEED_PAY = 0, 1, 2, 3


def b64url_decode(text):
    normalized = text.replace("-", "+").replace("_", "/")
    normalized += "=" * ((4 - len(normalized) % 4) % 4)
    return base64.b64decode(normalized).decode("utf-8")


def run(cmd, timeout=180):
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
            encoding="utf-8", errors="replace",
            shell=(os.name == "nt" and isinstance(cmd, str)),
        )
        return proc.returncode, (proc.stdout or "") + (proc.stderr or "")
    except (OSError, subprocess.SubprocessError) as error:
        return 1, str(error)


def parse_json_loose(text):
    """alipay-bot 的 --json 输出前可能有日志行，截取首尾花括号之间的部分。"""
    try:
        return json.loads(text)
    except ValueError:
        pass
    start, end = text.find("{"), text.rfind("}")
    if start >= 0 and end > start:
        try:
            return json.loads(text[start:end + 1])
        except ValueError:
            return None
    return None


def http_get(url, proof=None, timeout=180):
    request = urllib.request.Request(url, method="GET")
    request.add_header("Accept", "application/json")
    if proof:
        request.add_header("Payment-Proof", proof)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.status, dict(response.headers), response.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as error:
        return error.code, dict(error.headers), error.read().decode("utf-8", "replace")


def fetch_bill(url, out_dir):
    """取账单并原样落盘 —— 账单绝不能解码后再传给 CLI。"""
    try:
        status, headers, _body = http_get(url, timeout=60)
    except (urllib.error.URLError, TimeoutError) as error:
        print("请求失败：%s" % getattr(error, "reason", error))
        return None, None

    if status != 402:
        print("期望 402，实际 %d。资源地址异常，请联系卖家确认。" % status)
        return None, None

    raw = None
    for key, value in headers.items():
        if key.lower() == "payment-needed":
            raw = value
            break
    if not raw:
        print("收到 402 但没有 Payment-Needed 头。")
        return None, None

    bill = json.loads(b64url_decode(raw))
    path = os.path.join(out_dir, "402-needed-%d.txt" % int(time.time()))
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(raw.strip())
    return bill, path


def print_bill(bill):
    protocol = bill.get("protocol", {})
    method = bill.get("method", {})
    print("")
    print("需要支付")
    print("─" * 56)
    print("  商品    %s" % method.get("goods_name", "-"))
    print("  收款方  %s" % method.get("seller_name", "-"))
    print("  金额    %s %s" % (protocol.get("amount", "-"), protocol.get("currency", "")))
    print("  订单号  %s" % protocol.get("out_trade_no", "-"))
    print("  截止    %s" % protocol.get("pay_before", "-"))
    print("─" * 56)
    print("")


def find_delivery_node(node, depth=0):
    """递归找出含 delivery 的那一层。

    alipay-bot 的 --json 结构会随场景变化（有时 content 在顶层，有时嵌在 data/result 里），
    逐层硬取很容易漏，这里统一递归搜索。
    """
    if depth > 5:
        return None
    if isinstance(node, dict):
        content = node.get("content")
        if isinstance(content, str):
            try:
                inner = json.loads(content)
            except ValueError:
                inner = None
            if isinstance(inner, dict) and inner.get("delivery"):
                return inner
        for value in node.values():
            found = find_delivery_node(value, depth + 1)
            if found:
                return found
    elif isinstance(node, list):
        for item in node:
            found = find_delivery_node(item, depth + 1)
            if found:
                return found
    return None


def save_delivery(inner, out_dir, trade_no=None, already=False):
    """落盘 → 校验 SHA-256。传入已解析到 delivery 的那一层。"""
    delivery = inner.get("delivery")
    if not delivery:
        print("交付失败：响应里没有 delivery 字段")
        print(json.dumps(inner, ensure_ascii=False, indent=2)[:800])
        return EXIT_FAIL

    if delivery.get("type") == "text":
        target = os.path.join(out_dir, os.path.basename(delivery.get("file_name") or "delivery.txt"))
        with open(target, "w", encoding="utf-8") as handle:
            handle.write(delivery.get("content", ""))
        print("交付成功（文本）：%s" % os.path.abspath(target))
        return EXIT_OK

    raw = base64.b64decode(delivery.get("content_base64", ""))
    actual = hashlib.sha256(raw).hexdigest()
    declared = (delivery.get("sha256") or "").lower()
    target = os.path.join(out_dir, os.path.basename(delivery.get("file_name") or "delivery.zip"))
    with open(target, "wb") as handle:
        handle.write(raw)

    print("")
    print("交付成功")
    print("  文件      %s" % os.path.abspath(target))
    print("  大小      %d 字节（声明 %s）" % (len(raw), delivery.get("size_bytes", "-")))
    print("  SHA-256   %s" % actual)
    if trade_no:
        print("  交易号    %s" % trade_no)
    if already:
        print("  说明      复用既有产出，未重复扣费")

    if declared and actual != declared:
        print("")
        print("校验失败：摘要与服务端声明不一致，请用同一凭据重试，不要重新付款。")
        return EXIT_FAIL

    print("  校验通过")
    print("")
    print("解压后即为服务端源码目录，编译、配置与部署见包内 docs/接入教程.md。")
    return EXIT_OK


def query_once(bot, url, trade_no, timeout=180):
    """查一次支付状态，返回 (含 delivery 的节点 或 None, 退出码, 原始输出)。"""
    code, out = run([bot, "402-query-payment-status", "--json",
                     "--trade-no", trade_no, "-r", url, "-m", "GET"], timeout=timeout)
    data = parse_json_loose(out)
    inner = find_delivery_node(data) if data is not None else None
    return inner, code, out


def query_and_save(bot, url, trade_no, out_dir, timeout=180):
    inner, code, out = query_once(bot, url, trade_no, timeout)
    if inner:
        # CLI 有时因重复履约确认返回 exit 1，但资源已带回 —— 以拿到交付物为准
        return save_delivery(inner, out_dir, trade_no=trade_no)
    print("查询未返回交付物（exit %d）：" % code)
    print(out[-800:])
    print("")
    print("已付款的话稍后用同一交易号重试（**不要重新付款**）：")
    print("  python scripts/buy.py --trade-no %s" % trade_no)
    return EXIT_FAIL


def main():
    parser = argparse.ArgumentParser(description="付费技能服务端源码 · 一键购买")
    parser.add_argument("--trade-no", help="已付款时直接取货，跳过付款环节")
    parser.add_argument("--out", default=".", help="交付物输出目录，默认当前目录")
    parser.add_argument("--yes", action="store_true", help="跳过付款前的二次确认")
    parser.add_argument("--bot-path", help="alipay-bot 绝对路径")
    parser.add_argument("--url", default=os.environ.get("PAY_SERVICE_RESOURCE_URL", DEFAULT_RESOURCE_URL),
                        help="资源地址")
    parser.add_argument("--skip-preflight", action="store_true", help="跳过环境自检")
    parser.add_argument("--poll-interval", type=int, default=15, help="等待付款时的轮询间隔秒数")
    parser.add_argument("--poll-times", type=int, default=12, help="最多轮询次数")
    args = parser.parse_args()

    os.makedirs(args.out, exist_ok=True)

    # ── 1. 环境自检 ────────────────────────────────────────────
    if not args.skip_preflight:
        print("正在检查环境…")
        bot_state, bot_detail, bot_fix = check_bot(args.bot_path)
        # alipay-bot 已就绪时，Node 版本低只作提示（Windows 上 CLI 是原生二进制，不依赖 Node）
        checks = [
            ("Python", check_python()),
            ("Node.js", check_node(bot_ready=(bot_state == OK))),
            ("alipay-bot", (bot_state, bot_detail, bot_fix)),
        ]
        problems, warnings = [], []
        for name, (state, detail, _fix) in checks:
            if state == MISSING:
                problems.append("%s：%s" % (name, detail))
            elif state != OK:
                warnings.append("%s：%s" % (name, detail))
        for item in warnings:
            print("  ! %s（不阻断）" % item)
        if problems:
            print("")
            print("环境未就绪：")
            for item in problems:
                print("  ✗ %s" % item)
            print("")
            print("先跑：bash scripts/install-buyer-env.sh（Windows：install-buyer-env.ps1）")
            print("或看：references/buyer-env-setup.md")
            return EXIT_ENV
        print("环境就绪")

    bot = args.bot_path or find_alipay_bot()
    if not bot:
        print("未找到 alipay-bot，无法付款。")
        return EXIT_ENV

    # ── 2. 已付款 → 直接取货 ───────────────────────────────────
    if args.trade_no:
        return query_and_save(bot, args.url, args.trade_no, args.out)

    # ── 3. 取账单 ──────────────────────────────────────────────
    bill, bill_path = fetch_bill(args.url, args.out)
    if not bill:
        return EXIT_FAIL
    print_bill(bill)

    out_trade_no = bill.get("protocol", {}).get("out_trade_no", "-")
    pay_before = bill.get("protocol", {}).get("pay_before", "-")

    if not args.yes:
        print("订单号 %s，有效期至 %s。" % (out_trade_no, pay_before))
        try:
            answer = input("确认发起支付？[y/N] ").strip().lower()
        except EOFError:
            answer = "n"
        if answer not in ("y", "yes"):
            print("已取消。账单已保存在 %s，确认后再跑一次即可。" % bill_path)
            return EXIT_OK

    # ── 4. 发起支付 ────────────────────────────────────────────
    session_id = str(uuid.uuid4())
    code, out = run([bot, "402-buyer-pay", "--json", "--session-id", session_id,
                     "--file", bill_path, "--resource-url", args.url, "--method", "GET",
                     "--intent-summary", "购买付费技能服务端源码"], timeout=240)
    if code != 0:
        print("发起支付失败（exit %d）：" % code)
        print(out[-1000:])
        print("")
        print("常见原因：钱包未绑定、资源地址非 HTTPS、Node 版本低于 23。")
        print("跑 python scripts/preflight.py 看具体缺哪一项。")
        return EXIT_FAIL

    print("")
    print("支付已发起，请按上面的链接或二维码完成付款。")
    print("原始输出：")
    print(out.strip()[:1500])
    print("")

    data = parse_json_loose(out) or {}
    trade_no = None
    for key in ("trade_no", "tradeNo"):
        if data.get(key):
            trade_no = str(data[key])
    for node in (data.get("data"), data.get("result"), data.get("content")):
        if isinstance(node, dict) and not trade_no:
            for key in ("trade_no", "tradeNo"):
                if node.get(key):
                    trade_no = str(node[key])

    if trade_no:
        print("交易号：%s" % trade_no)
    else:
        print("未能从输出里自动识别交易号。")
        try:
            trade_no = input("请把上面的交易号（或支付链接里的 trade_no）粘贴到这里：").strip()
        except EOFError:
            trade_no = ""
    if not trade_no:
        print("没有交易号无法取货。已付款的话，用订单号 %s 找卖家核对。" % out_trade_no)
        return EXIT_NEED_PAY

    # ── 5. 等付款 + 轮询取货 ───────────────────────────────────
    print("")
    print("等待付款完成（每 %d 秒查一次，最多 %d 次）…" % (args.poll_interval, args.poll_times))
    for attempt in range(1, args.poll_times + 1):
        time.sleep(args.poll_interval if attempt > 1 else 5)
        print("  第 %d/%d 次查询…" % (attempt, args.poll_times))
        inner, _code, _out = query_once(bot, args.url, trade_no)
        if inner:
            return save_delivery(inner, args.out, trade_no=trade_no)
        print("  尚未到账或未完成履约，继续等待")

    print("")
    print("轮询结束仍未取到交付物。")
    print("付款已完成的话，稍后用同一交易号重试（**不要重新付款**）：")
    print("  python scripts/buy.py --trade-no %s" % trade_no)
    return EXIT_NEED_PAY


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n已中断。已付款的订单不会丢，用 --trade-no 重新取货即可。")
        sys.exit(EXIT_FAIL)
