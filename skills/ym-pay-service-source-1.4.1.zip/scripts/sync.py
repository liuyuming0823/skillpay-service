#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""技能自更新：与 SkillHub 上的版本比对，必要时把本技能替换为新版。

为什么需要它
------------
技能装到本地后就是一份**文件快照**，平台不会替用户检查版本。
取货器（本技能）一旦落后，用户可能卡在「取不到货」——
而这个失败通常发生在**付过钱之后**，代价很高。所以每次使用前先自检。

版本真相源为什么是 SkillHub
--------------------------
本技能本来就发布在 SkillHub 上（命名空间 @user_01de61f3），
「线上是哪个版本」只有它说了算。因此核对版本**不需要任何自建服务端**：
SkillHub 的公开接口免登录、由平台保障可用性，比自建服务稳得多。

用法
----
    python scripts/sync.py                # 只检查，不改动任何文件
    python scripts/sync.py --apply        # 检查，落后就更新
    python scripts/sync.py --json         # 机器可读输出（推荐给智能体）
    python scripts/sync.py --apply --json

退出码（智能体据此决定怎么跟用户说）
------------------------------------
    0   已是最新（或本次更新成功）
    10  有新版但未更新 —— 可以继续用旧版，但应提醒用户
    20  版本过低，协议已不兼容 —— 必须更新后才能继续
    30  联网核对失败 —— 已按旧版继续，不阻断用户
    1   出错
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
import urllib.error
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path

SKILL_CODE = "ym-pay-service-source"
SKILL_NAME = "付费技能服务端源码"
SKILL_DIR = Path(__file__).resolve().parent.parent
META_PATH = SKILL_DIR / "_meta.json"
CONFIG_PATH = SKILL_DIR / "config.json"
SKILL_MD = SKILL_DIR / "SKILL.md"

# 版本真相源：SkillHub 公开接口（无需登录）。
SKILLHUB_API = "https://api.skillhub.cn/api/v1"

# 属于本地安装状态的文件，绝不从包里覆盖：
#   config.json — 用户的本地配置，仅在缺失时用包内默认值创建。
#   _meta.json  — 由本脚本在安装成功后写入。包里即便夹带了它（发布者打包时的残留），
#                 也一律忽略：那是「发布者那时的安装状态」，装进来会让版本号失真。
KEEP_IF_EXISTS = {"config.json"}
NEVER_FROM_PACKAGE = {"_meta.json"}

# 无论新旧包怎么变，这些文件都留在原位、绝不删除。
#   scripts/sync.py 是本脚本自身。线上早期包（1.3.0）里并没有它，
#   若照「新版没有就当作陈旧文件删掉」处理，一更新就把自更新能力永久删掉，
#   而且悄无声息 —— 实测踩到过，必须硬保护。
NEVER_DELETE = {"config.json", "_meta.json", "scripts/sync.py"}

EXIT_OK = 0
EXIT_OUTDATED = 10
EXIT_HARD_REQUIRED = 20
EXIT_UNREACHABLE = 30
EXIT_ERROR = 1


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def load_json(path: Path) -> dict:
    try:
        with path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def parse_version(value: object) -> tuple:
    """把 ``1.4.0`` / ``v1.4.0`` 解析成可比较的元组。

    刻意不做字符串比较：``"1.10.0" < "1.9.0"`` 在字典序下成立，而那是错的。
    """
    text = str(value or "").strip()
    if text[:1] in ("v", "V"):
        text = text[1:]

    parts = []
    for chunk in text.split("."):
        digits = ""
        for char in chunk:
            if char.isdigit():
                digits += char
            else:
                break
        parts.append(int(digits) if digits else 0)

    return tuple(parts) if parts else (0,)


def is_newer(candidate: object, current: object) -> bool:
    return parse_version(candidate) > parse_version(current)


def major_of(value: object):
    match = re.match(r"^[vV]?(\d+)", str(value or "").strip())
    return int(match.group(1)) if match else None


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 256), b""):
            digest.update(block)
    return digest.hexdigest()


def http_get(url: str, timeout: float) -> bytes:
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "skill-self-update/2.0",
            "Accept": "application/json, */*",
        },
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def read_local_version() -> str:
    """本地版本以 SKILL.md 的 frontmatter 为准，回落到 _meta.json。

    不看 _meta.json 优先是因为：用户也可能是直接 `skillhub install` 装的，
    那种情况下 _meta.json 由包携带甚至根本不存在，版本号不可靠。
    SKILL.md 随包更新，才是「我这一份技能是什么版本」的权威来源。
    """
    try:
        text = SKILL_MD.read_text(encoding="utf-8")
        match = re.search(r"^version:\s*[\"']?([0-9][0-9A-Za-z.\-]*)", text, re.M)
        if match:
            return match.group(1).strip()
    except OSError:
        pass
    return str(load_json(META_PATH).get("version") or "").strip()


def resolve_source(explicit_manifest: str) -> tuple:
    """决定去哪儿核对版本，返回 ``(kind, url)``。

    默认走 SkillHub。只有下面这些情况才改用自建服务端的清单：
    ``--manifest-url`` → ``SKILL_UPDATE_MANIFEST_URL`` → ``PAY_SERVICE_BASE_URL``
    → ``config.json`` 的 ``manifest_url``。

    注意 ``config.json`` 只认 ``manifest_url`` 这个键；早期版本用的
    ``update_url`` 一律忽略 —— 它指向的是已经失效的临时隧道地址。
    """
    if explicit_manifest.strip():
        return "manifest", explicit_manifest.strip()

    env_url = os.environ.get("SKILL_UPDATE_MANIFEST_URL", "").strip()
    if env_url:
        return "manifest", env_url

    base = os.environ.get("PAY_SERVICE_BASE_URL", "").strip().rstrip("/")
    if base:
        return "manifest", f"{base}/v1/skills/{SKILL_CODE}/manifest"

    configured = str(load_json(CONFIG_PATH).get("manifest_url") or "").strip()
    if configured:
        return "manifest", configured

    return "skillhub", f"{SKILLHUB_API}/skills/{SKILL_CODE}"


def fetch_skillhub_manifest(url: str, timeout: float) -> dict:
    """把 SkillHub 的响应转成与自建清单同构的字段。

    SkillHub 不提供包摘要（sha256），下载校验只能靠 zip 自身的完整性检查；
    传输层由 HTTPS 保护，且包内容再经 zip CRC 校验，够用。
    """
    payload = json.loads(http_get(url, timeout).decode("utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("SkillHub 返回的不是 JSON 对象")

    latest = payload.get("latestVersion") or {}
    return {
        "version": str(latest.get("version") or "").strip(),
        "notes": str(latest.get("changelog") or "").strip(),
        "package_url": f"{SKILLHUB_API}/download?slug={SKILL_CODE}",
        "sha256": "",
        "min_supported_version": "",
    }


def fetch_server_manifest(url: str, timeout: float) -> dict:
    payload = json.loads(http_get(url, timeout).decode("utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("版本清单不是一个 JSON 对象")
    return payload


def infer_hard_required(current: str, latest: str) -> bool:
    """SkillHub 不声明「最低可用版本」，改由版本号语义推断。

    约定：**主版本号不同 = 协议不兼容**，必须更新。
    这样发布方控制硬阻断的方式就是「该 bump major 时 bump major」——
    既不依赖任何后端，也不需要额外的配置文件。
    """
    now_major, new_major = major_of(current), major_of(latest)
    if now_major is None or new_major is None:
        return False
    return now_major != new_major


def normalize_extracted_root(extract_dir: Path) -> Path:
    """压平「包里多套一层目录」的情况，否则文件会被摊到多余的一层里。"""
    entries = list(extract_dir.iterdir())

    if len(entries) == 1 and entries[0].is_dir():
        return entries[0]

    return extract_dir


def install_package(payload: Path, expected_sha256: str) -> list:
    """把新包落到技能目录，返回本次由包管理（且实际写入）的文件清单。

    策略是「以包为准覆盖，但绝不删包外的文件」：
    只清理上一版由本包管理、而新版已移除的文件；用户自己放进去的东西一律不动。
    这样即便判断失误，最坏情况也只是留下一个多余文件，不会误删用户数据。
    """
    actual = sha256_file(payload)
    expected = (expected_sha256 or "").strip().lower()

    if expected and actual != expected:
        raise RuntimeError(f"包摘要校验失败：期望 {expected}，实际 {actual}")

    previous_managed = set(load_json(META_PATH).get("managed_files") or [])

    with tempfile.TemporaryDirectory(prefix="skill-sync-") as tmp:
        extract_dir = Path(tmp) / "stage"
        extract_dir.mkdir(parents=True, exist_ok=True)

        with zipfile.ZipFile(payload) as archive:
            broken = archive.testzip()
            if broken:
                raise RuntimeError(f"压缩包损坏（首个坏条目：{broken}）")
            archive.extractall(extract_dir)

        root = normalize_extracted_root(extract_dir)
        managed = sorted(
            str(item.relative_to(root)).replace("\\", "/")
            for item in root.rglob("*")
            if item.is_file()
        )

        # 保护性检查：没有 SKILL.md 就不是一个技能包，宁可不动。
        if "SKILL.md" not in managed:
            raise RuntimeError("包内缺少 SKILL.md，拒绝安装（可能下载到了错误内容）")

        # 先删「上一版有、这一版没有」的文件。
        for relative in sorted(previous_managed):
            if relative in managed or relative in NEVER_DELETE:
                continue
            stale = SKILL_DIR / relative
            if stale.is_file():
                stale.unlink()

        # 再覆盖写入新版内容。
        installed = []
        for relative in managed:
            if relative in NEVER_FROM_PACKAGE:
                continue
            if relative in KEEP_IF_EXISTS and (SKILL_DIR / relative).exists():
                continue
            target = SKILL_DIR / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(root / relative, target)
            installed.append(relative)

    return installed


def write_meta(version: str, sha256: str, managed: list, source_url: str) -> None:
    meta = load_json(META_PATH)
    meta.update(
        {
            "slug": SKILL_CODE,
            "name": SKILL_NAME,
            "version": version,
            "installed_at": now_iso(),
            "sha256": sha256,
            "source_url": source_url,
            "managed_files": managed,
        }
    )
    META_PATH.write_text(
        json.dumps(meta, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def emit(result: dict, as_json: bool) -> None:
    if as_json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    print(f"技能 {result['skill_code']}")
    print(f"  版本来源  {result['source']}  {result['source_url']}")
    print(f"  本地版本  {result['current_version'] or '(未知)'}")
    if result["latest_version"]:
        print(f"  线上版本  {result['latest_version']}")
    if result["min_supported_version"]:
        print(f"  最低可用   {result['min_supported_version']}")
    print(f"  结论      {result['message']}")
    if result["notes"]:
        print(f"  更新说明  {result['notes']}")


def main() -> int:
    parser = argparse.ArgumentParser(description="比对并更新本技能到最新版本。")
    parser.add_argument("--apply", action="store_true", help="落后时直接更新（默认只检查）")
    parser.add_argument("--json", dest="as_json", action="store_true", help="输出 JSON，便于智能体解析")
    parser.add_argument("--manifest-url", default="", help="改用自建服务端的版本清单（一般不用）")
    parser.add_argument("--timeout", type=float, default=20.0, help="网络超时（秒）")
    args = parser.parse_args()

    kind, url = resolve_source(args.manifest_url)
    current = read_local_version()

    result = {
        "skill_code": SKILL_CODE,
        "skill_dir": str(SKILL_DIR),
        "source": kind,
        "source_url": url,
        "current_version": current,
        "latest_version": "",
        "min_supported_version": "",
        "status": "",
        "hard_required": False,
        "updated": False,
        "notes": "",
        "message": "",
    }

    try:
        manifest = (
            fetch_skillhub_manifest(url, args.timeout)
            if kind == "skillhub"
            else fetch_server_manifest(url, args.timeout)
        )
    except (urllib.error.URLError, OSError, ValueError, json.JSONDecodeError) as exc:
        # 核对不上不等于用户做错了什么，因此不阻断，只提示。
        # 用旧版继续比直接卡住用户更合适 —— 取货时服务端仍会校验。
        result["status"] = "unreachable"
        result["message"] = (
            f"没能连上 {result['source']} 核对版本（{exc}）。已按本地 {current or '未知'} 版继续；"
            "如果后续取货失败，先检查网络。"
        )
        emit(result, args.as_json)
        return EXIT_UNREACHABLE

    latest = str(manifest.get("version") or "").strip()
    minimum = str(manifest.get("min_supported_version") or "").strip()

    result["latest_version"] = latest
    result["min_supported_version"] = minimum
    result["notes"] = str(manifest.get("notes") or "")

    if not latest:
        result["status"] = "up-to-date"
        result["message"] = f"线上未声明版本号，按本地 {current or '未知'} 版继续。"
        emit(result, args.as_json)
        return EXIT_OK

    # 本地比线上还新：发布前的开发版，或线上被回滚。不动它，也不误导用户。
    if is_newer(current, latest):
        result["status"] = "ahead"
        result["message"] = (
            f"本地 {current} 高于线上 {latest}（未发布的开发版，或线上被回滚），不做改动。"
        )
        emit(result, args.as_json)
        return EXIT_OK

    has_update = is_newer(latest, current)

    # 「低于最低可用版本」必须独立于「有没有新版」判定。
    # 否则一旦最低可用线被抬高而 latest 没动，客户端会收到一句「已是最新」，
    # 然后继续用一个协议上根本不被支持的版本 —— 那是最坏的结果。
    hard_required = (
        bool(minimum) and is_newer(minimum, current)
    ) or infer_hard_required(current, latest)
    result["hard_required"] = hard_required

    if not has_update and not hard_required:
        result["status"] = "up-to-date"
        result["message"] = f"技能已是最新版本（{current or latest}）。"
        emit(result, args.as_json)
        return EXIT_OK

    target = latest or minimum
    result["status"] = "hard-required" if hard_required else "outdated"

    if not args.apply:
        result["message"] = (
            f"技能版本过低（{current or '未知'} < 最低可用 {minimum or latest}），"
            f"必须更新到 {target} 才能继续使用。"
            if hard_required
            else f"技能有新版本 {current or '未知'} → {latest}。建议更新："
            "线上协议一旦变化，旧版可能取不到货。"
        )
        emit(result, args.as_json)
        return EXIT_HARD_REQUIRED if hard_required else EXIT_OUTDATED

    package_url = str(manifest.get("package_url") or "").strip()

    if not package_url:
        result["status"] = "error"
        result["message"] = "版本信息里没有下载地址，无法自动更新；请手动重新安装本技能。"
        emit(result, args.as_json)
        return EXIT_ERROR

    try:
        with tempfile.TemporaryDirectory(prefix="skill-sync-") as tmp:
            payload = Path(tmp) / f"{SKILL_CODE}.zip"
            payload.write_bytes(http_get(package_url, max(args.timeout, 180.0)))
            managed = install_package(payload, str(manifest.get("sha256") or ""))
            write_meta(
                version=latest,
                sha256=sha256_file(payload),
                managed=managed,
                source_url=url,
            )
    except Exception as exc:  # noqa: BLE001 - 更新失败必须回报而不是崩掉
        result["status"] = "error"
        result["message"] = f"更新失败：{exc}。本地仍为 {current or '未知'} 版，可稍后重试。"
        emit(result, args.as_json)
        return EXIT_ERROR

    result["updated"] = True
    result["status"] = "updated"
    result["current_version"] = latest
    result["message"] = (
        f"技能已更新到 {latest}。"
        "请重新开始本次操作，让智能体读取更新后的技能内容再继续。"
    )
    if "scripts/sync.py" not in managed:
        # 新包漏打包了自更新器。文件已按 NEVER_DELETE 保留，功能不受影响，
        # 但要让发布方立刻看见 —— 否则下一版还漏。
        result["message"] += (
            "（提示：新包未包含 scripts/sync.py，已保留原有文件；"
            "建议发布方检查打包内容。）"
        )
    emit(result, args.as_json)
    return EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
