#!/usr/bin/env bash
# 付费技能服务端源码 · 买家环境一键安装（Linux / macOS）
#
#   bash scripts/install-buyer-env.sh
#
# 幂等：已满足的依赖会跳过，重复执行安全。
# 只装买家侧需要的东西（Node ≥23、alipay-bot、钱包引导），不装任何服务端组件。

set -uo pipefail

NODE_MIN=23
NODE_VERSION="v24.13.0"
NODE_DIR="/opt/node24"
BOT_URL="https://mdn.alipayobjects.com/aipay_assets/afts/file/waQLTqHHjLAAAAAAgKAAAAgAeoh5AQJr"
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

say()  { printf '\n\033[1m%s\033[0m\n' "$1"; }
ok()   { printf '  ✓ %s\n' "$1"; }
bad()  { printf '  ✗ %s\n' "$1"; }
info() { printf '    %s\n' "$1"; }

command -v node >/dev/null 2>&1 && export PATH="$(dirname "$(command -v node)"):$PATH"

# ── 1. Node.js ────────────────────────────────────────────────
say "1/4 检查 Node.js（alipay-bot 需要 ≥ ${NODE_MIN}）"

node_major() {
  command -v node >/dev/null 2>&1 || { echo 0; return; }
  node -v 2>/dev/null | sed 's/^v//' | cut -d. -f1
}

bot_version() {
  command -v alipay-bot >/dev/null 2>&1 || return 1
  alipay-bot --version >/dev/null 2>&1
}

if [ "$(node_major)" -ge "$NODE_MIN" ]; then
  ok "Node $(node -v) 已满足"
elif bot_version; then
  # Windows 的 alipay-bot 是原生二进制，Linux 上则由 Node 包装。
  # 已装好 CLI 时不强制升级 Node，只有要走 npx 安装才需要 ≥23。
  ok "Node $(node -v) 低于 ${NODE_MIN}，但 alipay-bot 已可用，跳过升级"
else
  bad "当前 $(command -v node >/dev/null 2>&1 && node -v || echo '未安装')，需要 ≥ ${NODE_MIN}（用 npx 安装 CLI 时）"
  arch="$(uname -m)"; os="$(uname -s)"
  case "$os:$arch" in
    Linux:x86_64)   pkg="node-${NODE_VERSION}-linux-x64" ;;
    Linux:aarch64)  pkg="node-${NODE_VERSION}-linux-arm64" ;;
    Darwin:x86_64)  pkg="node-${NODE_VERSION}-darwin-x64" ;;
    Darwin:arm64)   pkg="node-${NODE_VERSION}-darwin-arm64" ;;
    *) bad "未识别的平台 ${os}/${arch}，请手动安装 Node ${NODE_VERSION}"; exit 1 ;;
  esac

  info "从 npmmirror 下载 ${pkg}（nodejs.org 在部分网络不可达）"
  if mkdir -p "$NODE_DIR" 2>/dev/null && \
     curl -fsSL --connect-timeout 10 -m 300 \
       "https://npmmirror.com/mirrors/node/${NODE_VERSION}/${pkg}.tar.xz" \
       | tar -xJ -C "$NODE_DIR" --strip-components=1 2>/dev/null; then
    export PATH="${NODE_DIR}/bin:$PATH"
    ok "已安装到 ${NODE_DIR}：$(${NODE_DIR}/bin/node -v)"
    info "请把它写进你的 shell 配置，否则新开终端会失效："
    info "  echo 'export PATH=${NODE_DIR}/bin:\$PATH' >> ~/.bashrc && source ~/.bashrc"
  else
    bad "自动安装失败，请手动安装 Node ${NODE_VERSION} 后重跑本脚本"
    info "镜像地址：https://npmmirror.com/mirrors/node/${NODE_VERSION}/"
    exit 1
  fi
fi

# ── 2. alipay-bot CLI ─────────────────────────────────────────
say "2/4 安装 alipay-bot CLI"

if bot_version; then
  ok "alipay-bot 已安装（$(alipay-bot --version 2>&1 | head -1)）"
else
  info "尝试官方安装器…"
  if npx -y @alipay/agent-payment@latest install >/dev/null 2>&1 && bot_version; then
    ok "官方安装器成功"
  else
    info "官方安装器失败（已知问题：把 ZIP 当 tgz 解压），改用手动安装"
    tmp="$(mktemp -d)"
    if curl -fsSL --connect-timeout 10 -m 300 -o "$tmp/bot.zip" "$BOT_URL" && \
       (command -v unzip >/dev/null 2>&1 && unzip -oq "$tmp/bot.zip" -d "$tmp/bot" || \
        python3 -c "import zipfile,sys; zipfile.ZipFile('$tmp/bot.zip').extractall('$tmp/bot')"); then
      target="/usr/local/bin"
      if [ -w "$target" ]; then
        install -m 755 "$tmp/bot/alipay-bot" "$target/alipay-bot"
        cp -r "$tmp/bot/dist" "$target/"      # 关键：dist 必须与二进制同级
      else
        target="$HOME/.local/bin"; mkdir -p "$target"
        install -m 755 "$tmp/bot/alipay-bot" "$target/alipay-bot"
        cp -r "$tmp/bot/dist" "$target/"
        info "无 /usr/local/bin 写权限，已装到 $target"
        info "  echo 'export PATH=$target:\$PATH' >> ~/.bashrc && source ~/.bashrc"
        export PATH="$target:$PATH"
      fi
      ok "手动安装完成：$(alipay-bot --version 2>&1 | head -1)"
    else
      bad "下载或解压失败，请检查网络后重跑"
      exit 1
    fi
    rm -rf "$tmp"
  fi
fi

# 兜底：确认 dist 确实在二进制同级
BOT_PATH="$(command -v alipay-bot || true)"
if [ -n "$BOT_PATH" ] && [ ! -d "$(dirname "$BOT_PATH")/dist" ]; then
  bad "缺少同级 dist/，会报 'BlueShield addon is missing'"
  info "请把安装包内的 dist 目录复制到 $(dirname "$BOT_PATH")/"
fi

# ── 3. 钱包 ───────────────────────────────────────────────────
say "3/4 检查支付钱包"
if [ -n "$BOT_PATH" ]; then
  out="$("$BOT_PATH" check-wallet 2>&1 || true)"
  case "$out" in
    *已开启*|*bound*) ok "钱包已绑定" ;;
    *)
      bad "钱包未绑定，付款前必须完成（需要人工扫码，脚本无法代劳）"
      info "执行：alipay-bot apply-wallet --agent-name '<你的Agent名>'"
      info "扫码后：alipay-bot bind-wallet --code '<绑定指令>'"
      info "确认：  alipay-bot check-wallet"
      ;;
  esac
else
  bad "未找到 alipay-bot，跳过钱包检查"
fi

# ── 4. 技能目录 ───────────────────────────────────────────────
say "4/4 检查技能目录层级"
for root in "$HOME/.codebuddy/skills" "$HOME/.workbuddy/skills" "$HOME/.claude/skills"; do
  nested="$(find "$root" -mindepth 2 -maxdepth 2 -type d -name 'ym-pay-service-source' 2>/dev/null | head -1)"
  if [ -n "$nested" ]; then
    parent="$(dirname "$nested")"
    if [ "$(basename "$parent")" != "$(basename "$root")" ]; then
      info "发现嵌套目录（skillhub 安装会多套一层），正在移平："
      info "  $nested -> $root/ym-pay-service-source"
      mv "$nested" "$root/ym-pay-service-source" 2>/dev/null && rmdir "$parent" 2>/dev/null
      ok "已移平，平台现在能识别到这个技能"
    fi
  fi
done
ok "技能目录检查完成"

# ── 收尾 ──────────────────────────────────────────────────────
say "自检"
python3 "$SKILL_DIR/scripts/preflight.py" || true
echo ""
