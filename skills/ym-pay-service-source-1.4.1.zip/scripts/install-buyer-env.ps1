# 付费技能服务端源码 · 买家环境一键安装（Windows PowerShell）
#
#   powershell -ExecutionPolicy Bypass -File scripts\install-buyer-env.ps1
#
# 幂等：已满足的依赖会跳过，重复执行安全。

$ErrorActionPreference = 'Continue'
$NodeMin = 23

function Say($t) { Write-Host "`n$t" -ForegroundColor Cyan }
function Ok($t)  { Write-Host "  [OK] $t" -ForegroundColor Green }
function Bad($t) { Write-Host "  [!!] $t" -ForegroundColor Yellow }
function Tip($t) { Write-Host "       $t" -ForegroundColor Gray }

$SkillDir = Split-Path -Parent $PSScriptRoot

# ── 1. Node.js ────────────────────────────────────────────────
Say "1/4 检查 Node.js（alipay-bot 需要 >= $NodeMin）"
$node = Get-Command node -ErrorAction SilentlyContinue
$major = 0
if ($node) {
    $v = (node -v) -replace '^v',''
    $major = [int]($v.Split('.')[0])
}
if ($major -ge $NodeMin) {
    Ok "Node $(node -v) 已满足"
} else {
    Bad "当前 $(if ($node) { node -v } else { '未安装' })，需要 >= $NodeMin"
    Tip "请从 https://npmmirror.com/mirrors/node/ 下载 v24.x Windows 安装包"
    Tip "装完重开一个终端再跑本脚本"
}

# ── 2. alipay-bot CLI ─────────────────────────────────────────
Say "2/4 安装 alipay-bot CLI"
$botCandidates = @(
    (Join-Path $env:USERPROFILE '.openclaw-autoclaw\alipay-bot-cli\bin\alipay-bot.exe'),
    (Get-Command alipay-bot -ErrorAction SilentlyContinue).Source
) | Where-Object { $_ -and (Test-Path $_) }

$bot = $botCandidates | Select-Object -First 1
if ($bot) {
    Ok "alipay-bot 已安装：$bot"
} else {
    Tip "正在用官方安装器安装（需要 Node >= $NodeMin）…"
    & npx -y @alipay/agent-payment@latest install
    $bot = Join-Path $env:USERPROFILE '.openclaw-autoclaw\alipay-bot-cli\bin\alipay-bot.exe'
    if (Test-Path $bot) { Ok "安装完成：$bot" }
    else { Bad "未找到安装产物，请手动执行 npx -y @alipay/agent-payment@latest install 后查看输出" }
}

# BlueShield 插件必须与二进制同级
if ($bot) {
    $dist = Join-Path (Split-Path $bot -Parent) 'dist'
    if (Test-Path $dist) { Ok "BlueShield 插件已就位" }
    else { Bad "缺少同级 dist\，会报 'BlueShield addon is missing'" }
}

# ── 3. 钱包 ───────────────────────────────────────────────────
Say "3/4 检查支付钱包"
if ($bot) {
    $out = & $bot check-wallet 2>&1 | Out-String
    if ($out -match '已开启' -or $out -match 'bound') {
        Ok "钱包已绑定"
    } else {
        Bad "钱包未绑定，付款前必须完成（需要人工扫码）"
        Tip "alipay-bot apply-wallet --agent-name '<你的Agent名>'"
        Tip "扫码后：alipay-bot bind-wallet --code '<绑定指令>'"
        Tip "确认：  alipay-bot check-wallet"
    }
} else {
    Bad "未找到 alipay-bot，跳过钱包检查"
}

# ── 4. 技能目录 ───────────────────────────────────────────────
Say "4/4 检查技能目录层级"
foreach ($root in @("$env:USERPROFILE\.codebuddy\skills", "$env:USERPROFILE\.workbuddy\skills", "$env:USERPROFILE\.claude\skills")) {
    if (-not (Test-Path $root)) { continue }
    $nested = Get-ChildItem -Path $root -Recurse -Directory -Filter 'ym-pay-service-source' -ErrorAction SilentlyContinue |
              Where-Object { $_.Parent.FullName -ne $root } | Select-Object -First 1
    if ($nested) {
        Tip "移平嵌套目录：$($nested.FullName)"
        Move-Item -Path $nested.FullName -Destination (Join-Path $root 'ym-pay-service-source') -Force
        Ok "已移平"
    }
}
Ok "技能目录检查完成"

Say "自检"
$py = (Get-Command python -ErrorAction SilentlyContinue) -or (Get-Command python3 -ErrorAction SilentlyContinue)
if ($py) { & python (Join-Path $SkillDir 'scripts\preflight.py') } else { Bad "未找到 python，无法自检" }
Write-Host ""
