#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
付费技能服务端源码 · 买家环境自检

一次性告诉你缺什么、怎么补，避免在付款流程中途才撞上依赖坑。

    python scripts/preflight.py                      # 全量自检
    python scripts/preflight.py --bot-path <路径>     # 手动指定 alipay-bot
    python scripts/preflight.py --url <资源地址>      # 指定资源地址

退出码：0 全部就绪 · 1 有缺失项 · 2 资源地址不可用
"""

import argparse
import base64
import json
import os
import shutil
import subprocess
import sys
import urllib.error
import urllib.request

DEFAULT_RESOURCE_URL = "https://tile-maintenance-teddy-external.trycloudflare.com/v1/skills/ym-pay-service-source/result"
MIN_NODE_MAJOR = 23
MIN_PYTHON = (3, 8)

OK, MISSING, WARN = "ok", "missing", "warn"


def run(cmd, timeout=40):
    """执行外部命令，返回 (是否成功, 标准输出)。"""
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
            shell=(os.name == "nt" and isinstance(cmd, str)),
        )
        return proc.returncode == 0, (proc.stdout or proc.stderr or "").strip()
    except (OSError, subprocess.SubprocessError) as error:
        return False, str(error)


def version_tuple(text):
    """从 'v24.13.0' / 'alipay-bot-cli 0.4.3' 这类文本里取出主版本号。"""
    for token in text.replace("v", " ").split():
        parts = token.split(".")
        if parts and parts[0].isdigit():
            return tuple(int(p) for p in parts if p.isdigit())
    return None


def find_alipay_bot(explicit=None):
    """按优先级定位 alipay-bot：显式参数 → 环境变量 → PATH → 已知安装位置。"""
    candidates = []
    if explicit:
        candidates.append(explicit)
    if os.environ.get("ALIPAY_BOT_PATH"):
        candidates.append(os.environ["ALIPAY_BOT_PATH"])

    name = "alipay-bot.exe" if os.name == "nt" else "alipay-bot"
    found = shutil.which(name)
    if found:
        candidates.append(found)

    home = os.path.expanduser("~")
    candidates += [
        os.path.join(home, ".openclaw-autoclaw", "alipay-bot-cli", "bin", name),
        os.path.join(home, ".openclaw-autoclaw", "alipay-bot-cli", "bin", "alipay-bot"),
        "/usr/local/bin/alipay-bot",
        os.path.join(home, ".local", "bin", "alipay-bot"),
    ]

    for path in candidates:
        if path and os.path.isfile(path):
            return path
    return None


def check_python():
    current = sys.version_info[:2]
    ok = current >= MIN_PYTHON
    return (
        OK if ok else MISSING,
        "%d.%d.%d（需 ≥%d.%d）" % (sys.version_info[0], sys.version_info[1], sys.version_info[2], MIN_PYTHON[0], MIN_PYTHON[1]),
        "升级 Python 到 3.8 或更高",
    )


def check_node(bot_ready=False):
    """Node ≥23 只在需要用 npx 安装 alipay-bot 时才是硬性要求。

    Windows 上的 alipay-bot.exe 是原生二进制，实测 Node 22 也能正常付款；
    Linux 上 CLI 由 Node 包装，才真正要求 ≥23。因此 alipay-bot 已就绪时降级为警告。
    """
    found = shutil.which("node") or shutil.which("node.exe")
    if not found:
        if bot_ready:
            return WARN, "未找到，但 alipay-bot 已可用，不影响付款", ""
        return MISSING, "未找到（用 npx 安装 alipay-bot 需要 ≥%d）" % MIN_NODE_MAJOR, \
            "mkdir -p /opt/node24 && curl -sL https://npmmirror.com/mirrors/node/v24.13.0/node-v24.13.0-linux-x64.tar.xz | tar -xJ -C /opt/node24 --strip-components=1 && export PATH=/opt/node24/bin:$PATH"

    ok, out = run([found, "-v"])
    major = version_tuple(out)[0] if (ok and version_tuple(out)) else 0
    if major >= MIN_NODE_MAJOR:
        return OK, out, ""

    hint = "安装 Node %d 并把它的 bin 目录放到 PATH 最前面" % MIN_NODE_MAJOR
    if bot_ready:
        return WARN, "%s（低于 %d，但 alipay-bot 已可用；仅 npx 重装时才需升级）" % (out, MIN_NODE_MAJOR), ""
    return MISSING, "%s（需 ≥%d）" % (out or "未知", MIN_NODE_MAJOR), hint


def check_bot(explicit=None):
    path = find_alipay_bot(explicit)
    if not path:
        return MISSING, "未找到", \
            "npx -y @alipay/agent-payment@latest install"
    ok, out = run([path, "--version"])
    if not ok:
        return MISSING, "存在但执行失败：%s" % out[:120], \
            "重装：npx -y @alipay/agent-payment@latest install"
    version = version_tuple(out)
    if version and version[0] == 0 and version[1] < 4:
        return WARN, "%s（建议 ≥0.4.3）" % out, "npx -y @alipay/agent-payment@latest install"
    return OK, "%s  ·  %s" % (out, path), ""


def check_dist(explicit=None):
    """BlueShield 插件必须与二进制同级，否则报 'BlueShield addon is missing'。"""
    path = find_alipay_bot(explicit)
    if not path:
        return MISSING, "未找到 alipay-bot，跳过", ""
    sibling = os.path.join(os.path.dirname(os.path.abspath(path)), "dist")
    if os.path.isdir(sibling):
        return OK, "已就位（%s）" % sibling, ""
    return MISSING, "缺少同级 dist/（会报 BlueShield addon is missing）", \
        "把安装包内的 dist 目录复制到 %s" % os.path.dirname(os.path.abspath(path))


def check_wallet(explicit=None):
    path = find_alipay_bot(explicit)
    if not path:
        return MISSING, "未找到 alipay-bot，跳过", ""
    ok, out = run([path, "check-wallet", "--json"], timeout=60)
    bound = False
    if ok:
        try:
            data = json.loads(out[out.index("{"):out.rindex("}") + 1])
            bound = str(data.get("status", "")).lower() == "bound" or \
                "已开启" in str(data.get("message", ""))
        except ValueError:
            bound = "已开启" in out or '"status":"bound"' in out.replace(" ", "")
    if bound:
        return OK, "已开启支付宝支付功能", ""
    return MISSING, "钱包未绑定，无法付款", \
        "alipay-bot apply-wallet --agent-name '<你的Agent名>'  # 扫码后\n" \
        "      alipay-bot bind-wallet --code '<绑定指令>'\n" \
        "      alipay-bot check-wallet"


def check_resource(url):
    """资源地址必须是 HTTPS 且返回 402 —— 这两条任一不满足，付款一定失败。"""
    if not url.lower().startswith("https://"):
        return MISSING, "非 HTTPS（alipay-bot 会直接拒绝）：%s" % url, \
            "联系卖家确认最新的 HTTPS 资源地址，或用 PAY_SERVICE_RESOURCE_URL 覆盖"

    request = urllib.request.Request(url, method="GET")
    request.add_header("Accept", "application/json")
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            status = response.status
    except urllib.error.HTTPError as error:
        status = error.code
    except (urllib.error.URLError, TimeoutError) as error:
        return MISSING, "不可达：%s" % getattr(error, "reason", error), \
            "确认网络可出网；若地址来自隧道需确认隧道仍在运行"

    if status == 402:
        return OK, "可达且正常签发账单（HTTP 402）", ""
    if status == 404:
        return MISSING, "HTTP 404 资源未上架或地址已变更", "联系卖家确认资源地址，不要重试付款"
    return MISSING, "期望 402，实际 %d" % status, "联系卖家确认服务端状态"


def main():
    parser = argparse.ArgumentParser(description="买家环境自检")
    parser.add_argument("--bot-path", help="alipay-bot 绝对路径")
    parser.add_argument(
        "--url",
        default=os.environ.get("PAY_SERVICE_RESOURCE_URL", DEFAULT_RESOURCE_URL),
        help="资源地址，默认取环境变量 PAY_SERVICE_RESOURCE_URL 或内置地址",
    )
    parser.add_argument("--skip-wallet", action="store_true", help="跳过钱包检查（离线自检用）")
    args = parser.parse_args()

    # 先判 alipay-bot 是否就绪，再决定 Node 是硬性要求还是仅警告
    bot_state, bot_detail, bot_fix = check_bot(args.bot_path)

    checks = [
        ("Python", check_python()),
        ("Node.js", check_node(bot_ready=(bot_state == OK))),
        ("alipay-bot CLI", (bot_state, bot_detail, bot_fix)),
        ("BlueShield 插件", check_dist(args.bot_path)),
        ("支付钱包", (OK, "已跳过", "") if args.skip_wallet else check_wallet(args.bot_path)),
        ("资源地址", check_resource(args.url)),
    ]

    print("")
    print("环境自检 · 付费技能服务端源码")
    print("─" * 60)
    width = max(len(name) for name, _ in checks)
    for name, (state, detail, _fix) in checks:
        mark = "[✓]" if state == OK else ("[!]" if state == WARN else "[✗]")
        print("%s %s  %s" % (mark, name.ljust(width), detail))
    print("─" * 60)

    missing = [(n, d, f) for n, (s, d, f) in checks if s == MISSING]
    warned = [(n, d) for n, (s, d, _f) in checks if s == WARN]

    if warned:
        print("提示（不影响付款）：")
        for name, detail in warned:
            print("  %s — %s" % (name, detail))
        print("")

    if not missing:
        print("全部就绪，下一步：python scripts/buy.py")
        print("")
        return 0

    print("待补齐 %d 项：" % len(missing))
    print("")
    for name, detail, fix in missing:
        print("  %s — %s" % (name, detail))
        if fix:
            for line in fix.split("\n"):
                print("      %s" % line.strip())
        print("")
    print("大部分缺失项可由一键脚本处理：bash scripts/install-buyer-env.sh")
    print("（Windows 用 PowerShell 跑 scripts\\install-buyer-env.ps1）")
    print("")
    return 1


if __name__ == "__main__":
    sys.exit(main())
