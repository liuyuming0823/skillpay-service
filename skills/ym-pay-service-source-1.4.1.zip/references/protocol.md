# 402 协议与排错参考

需要手写客户端、核对字段含义，或排查「付了钱拿不到东西」时读这份文档。日常领取交付物只需 `scripts/fetch-source.py`。

## 一、交互全貌

```
客户端                          按量付费服务端
  │  ① GET/POST 资源地址              │
  │ ─────────────────────────────────>│  创建待支付订单并落库
  │  ② 402 + Payment-Needed 头        │
  │ <─────────────────────────────────│
  │                                   │
  │  ③ 用户完成支付（AI 付 / 手工）     │
  │                                   │
  │  ④ 带 Payment-Proof 重发同一请求    │
  │ ─────────────────────────────────>│  ⑤ 向支付宝验付
  │                                   │  ⑥ 校验本地订单（金额/资源/时效）
  │                                   │  ⑦ 生成交付物并落库
  │  ⑧ 200 + content（内含交付物）      │
  │ <─────────────────────────────────│
```

关键认识：**服务端不主动推送**。支付宝不会回调你的服务；是客户端带着凭据回来，服务端再去问支付宝「这笔钱到了吗」。

## 二、头字段

| 头 | 方向 | 说明 |
|---|---|---|
| `Payment-Needed` | 服务端 → 客户端 | Base64URL 编码的账单 JSON（见下节） |
| `Payment-Proof` | 客户端 → 服务端 | Base64URL 编码的付款凭据 JSON（见下节） |
| `Payment-Validation` | 服务端 → 客户端 | Base64URL 编码的回执，供留痕对账 |

**都用 Base64URL**：字符集是 `-` `_` 而非 `+` `/`，且可能省略 `=` 补位。按标准 Base64 解码会失败 —— 先补 `=` 再转 `+` `/`。

### Payment-Needed 解码后

```jsonc
{
  "protocol": {
    "out_trade_no": "SP20260917...",            // 商户订单号，对账唯一依据
    "amount": "29.90",                          // 金额（字符串，两位小数）
    "currency": "CNY",
    "resource_id": "paysvc:ym-pay-service-source",
    "pay_before": "2026-09-17T17:00:00+08:00",  // 支付截止时间
    "seller_signature": "...",                  // RSA2 签名
    "seller_sign_type": "RSA2",
    "seller_unique_id": "2088..."
  },
  "method": {
    "seller_name": "...",                       // 账单展示的商户名
    "seller_id": "2088...",
    "seller_app_id": "2021...",
    "goods_name": "...",                        // 账单展示的商品名
    "seller_unique_id_key": "seller_id",
    "service_id": "..."
  }
}
```

### 签名原文

固定 8 个字段，按字典序，`k=v` 用 `&` 连接：

```
amount=29.90&currency=CNY&goods_name=...&out_trade_no=...&pay_before=...&resource_id=...&seller_id=...&service_id=...
```

取值位置：`goods_name`、`seller_id`、`service_id` 在 `method` 节点，其余在 `protocol` 节点。用 `seller_signature` 可离线验证账单确实来自该服务端。

### Payment-Proof 组装后

```jsonc
{
  "protocol": {
    "payment_proof": "<支付工具给出的凭据>",
    "trade_no": "<支付宝交易号>"
  },
  "method": {
    "client_session": "<可选>"
  }
}
```

`protocol.payment_proof` 与 `protocol.trade_no` **都必填**，缺一即被判为凭据无效并退回 402。用 `scripts/fetch-source.py --make-proof` 生成，不要手搓 Base64。

> 验签失败的判据：RSA2 解出的填充头必须是 `0001ffff`。若你的客户端要独立验证账单签名，先用服务端返回的**支付宝公钥**核对，不要用本地遗留的旧公钥。

## 三、响应码对照

| 状态码 | 含义 | 客户端动作 |
|---|---|---|
| 402 | 需要支付，或凭据无效 | 取 `Payment-Needed` 发起支付，然后重试 |
| 200 | 交付成功 | 解析 `content` 并落盘，校验 `sha256` |
| 400 | 资源编码非法 | 检查地址拼写，**不要重试** |
| 404 | 资源未上架 | 检查服务端目录配置，**不要重试付款** |
| 500 / 502 | 服务端错误 | **保留凭据**，稍后用同一凭据重试 |

402 同时承担「需要支付」与「凭据无效」两种语义，这是刻意设计：客户端看到 402 重新走一遍支付流程即可，不需要区分具体原因。

## 四、200 响应结构

```jsonc
{
  "resource_id": "paysvc:ym-pay-service-source",
  "content": "{\"status\":\"success\",\"delivery\":{...}}",   // 是字符串，需再解析一层
  "trade_no": "20260917...",
  "out_trade_no": "SP20260917...",
  "already_fulfilled": false,       // 是否复用了既有产出
  "fulfillment_confirmed": true     // 履约是否已确认
}
```

`delivery` 节点：

| `delivery.type` | 字段 | 说明 |
|---|---|---|
| `file_base64` | `file_name` / `mime_type` / `size_bytes` / `sha256` / `content_base64` | 二进制交付物，Base64 内联 |
| `text` | `file_name` / `mime_type` / `size_bytes` / `sha256` / `content` | 文本交付物 |

## 五、排错清单

| 现象 | 原因 | 处理 |
|---|---|---|
| 用户提示「无法支付」 | 三处单价不一致 | 核对服务端配置、支付平台登记单价、技能标价，三者必须完全相同 |
| 付款后仍返回 402 | 本地订单校验未通过 | 看服务端日志里的三个布尔值：`amountMatches` / `resourceMatches` / `orderUsable` |
| `amountMatches=False` | 账单金额与订单金额不符 | 确认下单与验付之间没有改价 |
| `orderUsable=False` | 订单查不到或已过期 | 账单默认 30 分钟有效；也检查部署时是否清空了订单库 |
| 验付返回码非 10000 | 支付侧拒绝 | 看日志里的 `subCode`，多为签约状态或 serviceId 问题 |
| 超时但订单已付款 | 交付耗时超过客户端耐心 | 用**同一凭据**重试，**不要重新付款** |
| 交付内容与预期不符 | 交付物配错 | 核对服务端资源目录里该资源的交付配置 |
| 交付文件解压出错 | 传输或落盘被截断 | 重算 SHA-256 与 `delivery.sha256` 比对 |

## 六、手工调用示例

```bash
# 取账单（只看头部）
curl -si "http://111.230.145.82/v1/skills/ym-pay-service-source/result" | grep -i '^payment-needed'

# 解码账单
curl -s -D - -o /dev/null "http://111.230.145.82/v1/skills/ym-pay-service-source/result" \
  | grep -i '^payment-needed' | cut -d' ' -f2 \
  | tr '_-' '/+' | base64 -d 2>/dev/null | python3 -m json.tool

# 带凭据领取
curl -s -H "Payment-Proof: <Payment-Proof>" \
  "http://111.230.145.82/v1/skills/ym-pay-service-source/result" | python3 -m json.tool
```

Node.js 版本的客户端写法在**交付包内**（付后 zip 解出的 examples/client-sample.mjs，属于交付物，不是本技能目录里的文件）。
