# 买家环境依赖清单与安装手册

装完本技能后**先读这份文档**，把环境一次性备齐，再走付款。文档里所有命令都在 Linux / macOS / Windows 实测过，三个已知的安装坑在第四节单独列出。

## 一、依赖总览

| 依赖 | 是否必需 | 版本要求 | 用来干什么 |
|---|---|---|---|
| Python | **必需** | ≥ 3.8（仅标准库） | 跑本技能的 `preflight.py` / `buy.py` / `fetch-source.py` |
| Node.js | **必需** | ≥ 23 | `alipay-bot` 的运行环境，低于 23 会直接报「当前 Node.js 版本过低」 |
| alipay-bot CLI | **必需**（平台无内置支付能力时） | ≥ 0.4.3 | 生成支付链接与二维码、查询支付状态、取回交付物 |
| 支付宝 AI 付钱包 | **必需** | 已绑定 | 付这笔钱的前提；未绑定则无法付款 |
| skillhub CLI | 条件必需 | 任意 | 只有「用命令行装技能」时才需要；平台一键安装不需要 |
| 域名 / 证书 / 服务端 | **不需要** | — | 这些是**卖家**侧的事，买家不用管 |

**如果你所在的平台已经内置了支付宝 AI 付 / 402 支付能力**（多数 Agent 平台已内置），Node.js、alipay-bot、钱包这三项可以全部跳过，让平台自己完成付款，你只需要拿到 `Payment-Proof` 后执行 `python scripts/fetch-source.py --proof "<...>"`。

## 二、最省事的安装路径（推荐先试这条）

```bash
# 1) Node.js ≥23（已有就跳过，用 node -v 看）
node -v

# 2) 装 alipay-bot（官方安装器，Windows / Linux / macOS 通用，退出码 0 即成功）
npx -y @alipay/agent-payment@latest install

# 3) 验证
alipay-bot --version        # 期望 0.4.3 或更高
alipay-bot check-wallet     # 期望「已开启支付宝支付功能」
```

安装器默认把 CLI 放在：

| 系统 | 路径 |
|---|---|
| Windows | `~/.openclaw-autoclaw/alipay-bot-cli/bin/alipay-bot.exe` |
| Linux / macOS | 通常在 `PATH` 内，或 `~/.openclaw-autoclaw/alipay-bot-cli/bin/alipay-bot` |

若 `alipay-bot` 不在 `PATH` 里，把它所在目录加进去，或用 `scripts/preflight.py --bot-path <绝对路径>` 显式指定。

## 三、逐项安装（官方安装器失败时照这节来）

### Node.js ≥ 23

`nodejs.org` 在部分网络不可达，用 npmmirror 镜像：

```bash
# Linux x64
mkdir -p /opt/node24
curl -sL "https://npmmirror.com/mirrors/node/v24.13.0/node-v24.13.0-linux-x64.tar.xz" \
  | tar -xJ -C /opt/node24 --strip-components=1
export PATH="/opt/node24/bin:$PATH"
node -v     # v24.13.0
```

macOS / Windows 直接从 `npmmirror.com/mirrors/node/` 下载对应安装包即可。

### alipay-bot CLI

官方安装器在部分 Linux 环境会因「把 ZIP 当 tgz 解压」而失败，手动装一遍即可：

```bash
mkdir -p /tmp/aipay && cd /tmp/aipay
curl -sL -o bot.zip "https://mdn.alipayobjects.com/aipay_assets/afts/file/waQLTqHHjLAAAAAAgKAAAAgAeoh5AQJr"
unzip -o -q bot.zip -d bot
install -m 755 bot/alipay-bot /usr/local/bin/alipay-bot
cp -r bot/dist /usr/local/bin/          # 关键：dist 必须与二进制同级
alipay-bot --version
```

### 钱包绑定（只需做一次）

```bash
alipay-bot check-wallet
# 若提示未绑定：
alipay-bot apply-wallet --agent-name '<你的Agent名>'   # 输出二维码，扫码
alipay-bot bind-wallet --code '<扫码后拿到的绑定指令>'
alipay-bot check-wallet                                 # 必须显示「已开启支付宝支付功能」
```

### skillhub CLI（命令行装技能时才用）

官网给的是一行式安装（下载与执行连在一起）。建议拆成**先下载、看过内容再执行**——脚本会以当前用户权限改 `~/.local/bin`，值得花十秒瞄一眼：

```bash
curl -fsSL -o /tmp/skillhub-install.sh \   # 该脚本为运行时产物，不在技能包内
  https://skillhub-1388575217.cos.ap-guangzhou.myqcloud.com/install/install.sh
cat /tmp/skillhub-install.sh     # 脚本内容（运行时产物），确认无异常再继续
bash /tmp/skillhub-install.sh    # 执行下载的脚本（运行时产物）
```

**风险与回滚**：该脚本只往 `~/.local/bin` 写 `skillhub` 一个可执行文件，不碰 sudo、不改 PATH 之外的配置。出问题删掉 `~/.local/bin/skillhub` 即恢复原状。

## 四、三个必踩的坑（提前规避能省半小时）

| 现象 | 根因 | 处理 |
|---|---|---|
| 装完技能不生效、平台识别不到 | `skillhub install` 会多套一层 `@命名空间/` 目录 | 移平：`cd ~/.codebuddy/skills && mv "@user_01de61f3/ym-pay-service-source" ./ym-pay-service-source && rmdir "@user_01de61f3"` |
| `当前 Node.js 版本过低`（如 v22.13.1） | CLI 要求 ≥ 23 | 按第三节装 Node 24，并确认 `node -v` 生效 |
| `BlueShield addon is missing` | 安全插件 `dist/` 必须与二进制**同级** | `dist/` 放在 `/usr/local/bin/dist/`，不是 `~/.local/share/alipay-bot-cli/` |
| `tar: This does not look like a tar archive` | 官方包实为 ZIP，安装器按 `.tgz` 解（CLI bug） | 按第三节手动 `unzip` 安装 |

## 五、装完自检

```bash
python scripts/preflight.py
```

全部 `[✓]` 就可以直接 `python scripts/buy.py`；有 `[✗]` 时脚本会打印对应修复命令。
